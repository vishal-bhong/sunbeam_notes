﻿namespace _0000DemoMVC.Models
{
    public class Customer
    {
        public int No { get; set; }
        public string Name { get; set; }
        public string Address { get; set; }
    }
}
