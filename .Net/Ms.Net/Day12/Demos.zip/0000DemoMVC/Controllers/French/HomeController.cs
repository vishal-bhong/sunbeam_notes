﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Controllers;

namespace _0000DemoMVC.Controllers.French
{
    //public class HomeController : Controller
    //{
    //    public ActionResult Index()
    //    {
    //        return View();
    //    }
    //}

    //public class MyControllerFactory : IControllerFactory
    //{
    //    public object CreateController(ControllerContext context)
    //    {
    //        //In default factory what code is written??
    //        //if the url is /home/index 
    //        //Find the class by the name HomeController
    //        //inside currrent assemly using reflection
    //        //create a object
    //        //return that object from here


    //        //You take decision here - which controller class
    //        //object to return??
    //        return null;
    //    }

    //    public void ReleaseController(ControllerContext context, object controller)
    //    {
    //        throw new NotImplementedException();
    //    }
    //}
}