﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _27Demo_Features
{

    //This is File 1. CS File
    //Written by Parth
    public partial class Maths
	{
		public int Add(int x , int y)
		{
			return x + y;
		}
	}
}
